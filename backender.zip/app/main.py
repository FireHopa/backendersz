from __future__ import annotations
import json
import uuid
import hashlib
import io
import re
import httpx
import asyncio
import os
from typing import Any, Dict, List, Optional
from fastapi.responses import StreamingResponse
from urllib.parse import urlencode

try:
    import pypdf
except ImportError:
    pypdf = None
try:
    import docx
except ImportError:
    docx = None

from datetime import datetime, timedelta

from fastapi import FastAPI, BackgroundTasks, Depends, HTTPException, UploadFile, File
from fastapi.middleware.cors import CORSMiddleware
from sqlmodel import Session, select

from .config import LINKEDIN_CLIENT_ID, LINKEDIN_CLIENT_SECRET, LINKEDIN_REDIRECT_URI
from .db import init_db, get_session
from .models import Robot, ChatMessage, CompetitionAnalysis, AuthorityEdit, AuthorityAgentRun, BusinessCore, User
from .schemas import (
    BriefingIn,
    RobotOut,
    RobotDetail,
    RobotUpdateIn,
    ChatIn,
    ChatMessageOut,
    MessageUpdateIn,
    AuthorityAssistantIn,
    AuthorityAssistantOut,
    AuthorityEditOut,
    AuthorityAgentRunIn,
    AuthorityAgentHistoryOut,
    AuthorityAgentRunOut,
    CompetitionFindRequest,
    CompetitionAnalyzeRequest,
    CompetitionJobV2Out,
    CompetitionReportV2Out,
    CompetitionFindOut,
    LinkedInConnectIn
)
from .ai import build_robot_from_briefing, chat_with_robot, transcribe_audio, find_competitors, build_competition_result, authority_assistant, run_authority_agent

from .deps import get_current_user
from .auth import router as auth_router
from pydantic import BaseModel


class SuggestThemesRequest(BaseModel):
    agent_key: str
    task: str
    nucleus: dict


app = FastAPI(title="Authority Robot Panel API")

app.include_router(auth_router)


async def extract_text_from_file(file: UploadFile) -> str:
    content = await file.read()
    filename = file.filename.lower()
    text = ""

    if filename.endswith(".pdf"):
        if not pypdf:
            raise HTTPException(status_code=500, detail="pypdf não instalado no backend.")
        try:
            reader = pypdf.PdfReader(io.BytesIO(content))
            for page in reader.pages:
                extracted = page.extract_text()
                if extracted:
                    text += extracted + "\n"
        except Exception as e:
            raise HTTPException(status_code=400, detail=f"Erro ao ler o PDF: {str(e)}")

    elif filename.endswith(".docx"):
        if not docx:
            raise HTTPException(status_code=500, detail="python-docx não instalado.")
        try:
            doc = docx.Document(io.BytesIO(content))
            for para in doc.paragraphs:
                text += para.text + "\n"
        except Exception as e:
            raise HTTPException(status_code=400, detail=f"Erro ao ler o DOCX: {str(e)}")

    elif filename.endswith(".txt") or filename.endswith(".md") or filename.endswith(".csv"):
        try:
            text = content.decode("utf-8")
        except Exception:
            text = content.decode("latin-1", errors="ignore")
    else:
        raise HTTPException(status_code=400, detail="Formato não suportado. Utilize PDF, DOCX, TXT ou MD.")

    return text.strip()


app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.on_event("startup")
def _startup():
    init_db()


def _get_robot_or_404(public_id: str, session: Session, current_user: User) -> Robot:
    if public_id == "business-core-global":
        robot = session.exec(select(Robot).where(Robot.public_id == public_id)).first()
        if not robot:
            robot = Robot(
                public_id="business-core-global",
                title="[SISTEMA] Núcleo Global",
                description="Armazena os ficheiros do Núcleo da Empresa.",
                system_instructions="Não usado diretamente no chat."
            )
            session.add(robot)
            session.commit()
            session.refresh(robot)
        return robot

    robot = session.exec(select(Robot).where(Robot.public_id == public_id, Robot.user_id == current_user.id)).first()
    if not robot:
        raise HTTPException(status_code=404, detail="Assistente não encontrado ou não tem permissão para aceder.")
    return robot


@app.get("/api/robots", response_model=list[RobotOut])
def list_robots(session: Session = Depends(get_session), current_user: User = Depends(get_current_user)):
    robots = session.exec(
        select(Robot)
        .where(Robot.public_id != "business-core-global")
        .where(Robot.user_id == current_user.id)
        .order_by(Robot.created_at.desc())
    ).all()
    return [
        RobotOut(
            public_id=r.public_id,
            title=r.title,
            description=r.description or "",
            avatar_data=r.avatar_data,
            created_at=r.created_at.isoformat(),
        )
        for r in robots
    ]


@app.get("/api/robots/{public_id}", response_model=RobotDetail)
def get_robot(public_id: str, session: Session = Depends(get_session), current_user: User = Depends(get_current_user)):
    robot = _get_robot_or_404(public_id, session, current_user)
    return RobotDetail(
        public_id=robot.public_id,
        title=robot.title,
        description=robot.description or "",
        avatar_data=robot.avatar_data,
        system_instructions=robot.system_instructions,
        created_at=robot.created_at.isoformat(),
        knowledge_files_json=robot.knowledge_files_json
    )


@app.delete("/api/robots/{public_id}")
def delete_robot(public_id: str, session: Session = Depends(get_session), current_user: User = Depends(get_current_user)):
    robot = _get_robot_or_404(public_id, session, current_user)
    msgs = session.exec(select(ChatMessage).where(ChatMessage.robot_id == robot.id)).all()
    for m in msgs:
        session.delete(m)
    session.delete(robot)
    session.commit()
    return {"ok": True}


@app.post("/api/robots", response_model=RobotOut)
def create_robot(brief: BriefingIn, session: Session = Depends(get_session), current_user: User = Depends(get_current_user)):
    try:
        built = build_robot_from_briefing(brief.model_dump())
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

    robot = Robot(
        user_id=current_user.id,
        public_id=uuid.uuid4().hex,
        title=built["title"],
        description=built.get("description") or "",
        avatar_data=None,
        system_instructions=built["system_instructions"],
    )
    session.add(robot)
    session.commit()
    session.refresh(robot)

    return RobotOut(
        public_id=robot.public_id,
        title=robot.title,
        description=robot.description or "",
        avatar_data=robot.avatar_data,
        created_at=robot.created_at.isoformat(),
    )


@app.patch("/api/robots/{public_id}", response_model=RobotDetail)
def update_robot(public_id: str, body: RobotUpdateIn, session: Session = Depends(get_session), current_user: User = Depends(get_current_user)):
    robot = _get_robot_or_404(public_id, session, current_user)
    data = body.model_dump(exclude_unset=True)
    for k, v in data.items():
        setattr(robot, k, v)
    session.add(robot)
    session.commit()
    session.refresh(robot)
    return RobotDetail(
        public_id=robot.public_id,
        title=robot.title,
        description=robot.description or "",
        avatar_data=robot.avatar_data,
        system_instructions=robot.system_instructions,
        created_at=robot.created_at.isoformat(),
        knowledge_files_json=robot.knowledge_files_json
    )


@app.get("/api/robots/{public_id}/business-core")
def get_business_core(public_id: str, session: Session = Depends(get_session), current_user: User = Depends(get_current_user)):
    robot = _get_robot_or_404(public_id, session, current_user)
    core = session.exec(select(BusinessCore).where(BusinessCore.robot_id == robot.id)).first()

    if not core:
        core = BusinessCore(robot_id=robot.id)
        session.add(core)
        session.commit()
        session.refresh(core)

    return core


@app.patch("/api/robots/{public_id}/business-core")
def update_business_core(public_id: str, payload: dict, session: Session = Depends(get_session), current_user: User = Depends(get_current_user)):
    robot = _get_robot_or_404(public_id, session, current_user)
    core = session.exec(select(BusinessCore).where(BusinessCore.robot_id == robot.id)).first()

    if not core:
        core = BusinessCore(robot_id=robot.id)
        session.add(core)

    for k, v in payload.items():
        if hasattr(core, k) and v is not None and k not in ("id", "robot_id"):
            setattr(core, k, v)

    core.updated_at = datetime.utcnow()
    session.add(core)
    session.commit()
    session.refresh(core)
    return core


@app.get("/api/robots/{public_id}/messages", response_model=list[ChatMessageOut])
def list_messages(public_id: str, session: Session = Depends(get_session), current_user: User = Depends(get_current_user)):
    robot = _get_robot_or_404(public_id, session, current_user)
    msgs = session.exec(
        select(ChatMessage)
        .where(ChatMessage.robot_id == robot.id)
        .order_by(ChatMessage.created_at.asc())
    ).all()
    return [
        ChatMessageOut(id=m.id, role=m.role, content=m.content, created_at=m.created_at.isoformat())
        for m in msgs
    ]


@app.post("/api/robots/{public_id}/authority-assistant", response_model=AuthorityAssistantOut)
def authority_assistant_route(public_id: str, body: AuthorityAssistantIn, session: Session = Depends(get_session), current_user: User = Depends(get_current_user)):
    robot = _get_robot_or_404(public_id, session, current_user)

    edits = session.exec(
        select(AuthorityEdit)
        .where(AuthorityEdit.robot_id == robot.id)
        .order_by(AuthorityEdit.created_at.desc())
    ).all()
    edits_history = []
    for e in edits[:30]:
        try:
            changes = json.loads(e.changes_json or "[]")
        except Exception:
            changes = []
        edits_history.append(
            {
                "id": e.id,
                "created_at": e.created_at.isoformat(),
                "user_message": e.user_message,
                "summary": e.summary or "",
                "changes_made": changes,
                "before_score": e.before_score,
                "after_score": e.after_score,
            }
        )

    before_instructions = robot.system_instructions or ""
    before_hash = hashlib.sha256(before_instructions.encode("utf-8")).hexdigest()

    result = authority_assistant(
        robot_system_instructions=before_instructions,
        user_message=body.message,
        history=body.history or [],
        authority_edits_history=edits_history,
    )

    if result.get("apply_change") and result.get("updated_system_instructions"):
        updated = str(result["updated_system_instructions"])
        after_hash = hashlib.sha256(updated.encode("utf-8")).hexdigest()

        exists = session.exec(
            select(AuthorityEdit).where(
                AuthorityEdit.robot_id == robot.id,
                AuthorityEdit.after_hash == after_hash,
            )
        ).first()

        if not exists:
            robot.system_instructions = updated
            session.add(robot)
            session.commit()
            session.refresh(robot)

            changes_made = result.get("changes_made") or []
            summary = ""
            if isinstance(changes_made, list) and changes_made:
                summary = "; ".join(
                    [str(c.get("title") or c.get("change") or c.get("what") or "").strip() for c in changes_made]
                )[:280]

            edit = AuthorityEdit(
                robot_id=robot.id,
                user_message=str(body.message),
                assistant_reply=str(result.get("assistant_reply") or ""),
                changes_json=json.dumps(changes_made, ensure_ascii=False),
                summary=summary,
                before_score=int(result.get("before_score") or 0),
                after_score=int(result.get("after_score") or 0),
                before_hash=before_hash,
                after_hash=after_hash,
            )
            session.add(edit)
            session.commit()

    return AuthorityAssistantOut(
        apply_change=bool(result.get("apply_change") or False),
        before_score=int(result.get("before_score") or 0),
        after_score=int(result.get("after_score") or 0),
        criteria=list(result.get("criteria") or []),
        changes_made=list(result.get("changes_made") or []),
        suggestions=list(result.get("suggestions") or []),
        updated_system_instructions=result.get("updated_system_instructions"),
        assistant_reply=str(result.get("assistant_reply") or ""),
    )


@app.get("/api/robots/{public_id}/authority-edits", response_model=list[AuthorityEditOut])
def list_authority_edits(public_id: str, session: Session = Depends(get_session), current_user: User = Depends(get_current_user)):
    robot = _get_robot_or_404(public_id, session, current_user)
    edits = session.exec(
        select(AuthorityEdit)
        .where(AuthorityEdit.robot_id == robot.id)
        .order_by(AuthorityEdit.created_at.desc())
    ).all()
    out: list[AuthorityEditOut] = []
    for e in edits:
        try:
            changes = json.loads(e.changes_json or "[]")
        except Exception:
            changes = []
        out.append(
            AuthorityEditOut(
                id=e.id,
                created_at=e.created_at.isoformat(),
                user_message=e.user_message,
                summary=e.summary or "",
                changes_made=changes,
                before_score=e.before_score,
                after_score=e.after_score,
            )
        )
    return out


@app.delete("/api/robots/{public_id}/messages")
def clear_messages(public_id: str, session: Session = Depends(get_session), current_user: User = Depends(get_current_user)):
    robot = _get_robot_or_404(public_id, session, current_user)
    msgs = session.exec(select(ChatMessage).where(ChatMessage.robot_id == robot.id)).all()
    for m in msgs:
        session.delete(m)
    session.commit()
    return {"ok": True}


@app.patch("/api/robots/{public_id}/messages/{message_id}", response_model=ChatMessageOut)
def update_message(public_id: str, message_id: int, body: MessageUpdateIn, session: Session = Depends(get_session), current_user: User = Depends(get_current_user)):
    robot = _get_robot_or_404(public_id, session, current_user)
    msg = session.exec(
        select(ChatMessage).where(ChatMessage.id == message_id, ChatMessage.robot_id == robot.id)
    ).first()
    if not msg:
        raise HTTPException(status_code=404, detail="Mensagem não encontrada")
    if msg.role != "user":
        raise HTTPException(status_code=400, detail="Só é permitido editar mensagens do utilizador")

    msg.content = body.content
    session.add(msg)
    session.commit()
    session.refresh(msg)
    return ChatMessageOut(id=msg.id, role=msg.role, content=msg.content, created_at=msg.created_at.isoformat())


@app.post("/api/robots/{public_id}/audio", response_model=ChatMessageOut)
async def chat_audio(public_id: str, file: UploadFile = File(...), session: Session = Depends(get_session), current_user: User = Depends(get_current_user)):
    robot = _get_robot_or_404(public_id, session, current_user)
    audio_bytes = await file.read()
    try:
        text = transcribe_audio(audio_bytes, filename=file.filename or "audio.webm")
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Falha ao transcrever o áudio: {e}")

    msgs = session.exec(
        select(ChatMessage)
        .where(ChatMessage.robot_id == robot.id)
        .order_by(ChatMessage.created_at.asc())
    ).all()
    history = [{"role": m.role, "content": m.content} for m in msgs][-20:]

    user_msg = ChatMessage(robot_id=robot.id, role="user", content=text)
    session.add(user_msg)
    session.commit()
    session.refresh(user_msg)

    try:
        answer = chat_with_robot(robot.system_instructions, history, text)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

    assistant_msg = ChatMessage(robot_id=robot.id, role="assistant", content=answer)
    session.add(assistant_msg)
    session.commit()
    session.refresh(assistant_msg)

    return ChatMessageOut(
        id=assistant_msg.id,
        role=assistant_msg.role,
        content=assistant_msg.content,
        created_at=assistant_msg.created_at.isoformat(),
    )


@app.post("/api/robots/{public_id}/chat", response_model=ChatMessageOut)
def chat(public_id: str, body: ChatIn, session: Session = Depends(get_session), current_user: User = Depends(get_current_user)):
    robot = _get_robot_or_404(public_id, session, current_user)
    msgs = session.exec(
        select(ChatMessage)
        .where(ChatMessage.robot_id == robot.id)
        .order_by(ChatMessage.created_at.asc())
    ).all()
    history = [{"role": m.role, "content": m.content} for m in msgs][-20:]

    user_msg = ChatMessage(robot_id=robot.id, role="user", content=body.message)
    session.add(user_msg)
    session.commit()
    session.refresh(user_msg)

    try:
        answer = chat_with_robot(
            robot.system_instructions,
            history,
            body.message,
            use_web=body.use_web,
            web_max_results=body.web_max_results,
            web_allowed_domains=body.web_allowed_domains
        )
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

    assistant_msg = ChatMessage(robot_id=robot.id, role="assistant", content=answer)
    session.add(assistant_msg)
    session.commit()
    session.refresh(assistant_msg)

    return ChatMessageOut(
        id=assistant_msg.id,
        role=assistant_msg.role,
        content=assistant_msg.content,
        created_at=assistant_msg.created_at.isoformat(),
    )


def _update_analysis(session, obj, **kwargs):
    for k, v in kwargs.items():
        setattr(obj, k, v)
    obj.updated_at = datetime.utcnow()
    session.add(obj)
    session.commit()
    session.refresh(obj)


def _domain(url: str) -> str:
    from urllib.parse import urlparse
    try:
        return urlparse(url).netloc
    except Exception:
        return url


def _run_analysis_job(public_id: str):
    from sqlmodel import Session
    from .db import engine
    import json
    from .ai import build_competition_result

    with Session(engine) as session:
        obj = None
        try:
            obj = session.exec(select(CompetitionAnalysis).where(CompetitionAnalysis.public_id == public_id)).first()
            if not obj:
                return

            _update_analysis(session, obj, status="running", stage="Coletando sinais públicos", progress=0.15)

            instagrams = json.loads(obj.instagrams_json or "[]")
            sites = json.loads(obj.sites_json or "[]")
            company = json.loads(obj.company_json or "{}") if obj.company_json else {}

            competitors = []
            for s in sites:
                competitors.append({"name": _domain(s), "website_url": s})

            _update_analysis(session, obj, stage="Analisando presença digital", progress=0.40)
            _update_analysis(session, obj, stage="Consolidando inteligência", progress=0.75)

            result = build_competition_result(company=company, competitors=competitors[:3])

            _update_analysis(session, obj, status="done", stage="Concluído", progress=1.0, result_json=json.dumps(result, ensure_ascii=False))

        except Exception as e:
            if obj:
                _update_analysis(session, obj, status="error", stage="Erro no processamento", progress=1.0, error=str(e))


@app.post("/api/competition/find-competitors", response_model=CompetitionFindOut)
def competition_find_competitors_v2(payload: CompetitionFindRequest, current_user: User = Depends(get_current_user)):
    briefing = payload.briefing.model_dump()
    mapped = {
        "company_name": briefing.get("nome_empresa"),
        "niche": briefing.get("segmento"),
        "region": briefing.get("cidade_estado"),
        "services": briefing.get("servicos"),
        "audience": briefing.get("publico_alvo"),
        "offer": briefing.get("servicos"),
    }
    data = find_competitors(mapped)
    return data


@app.post("/api/competition/analyze", response_model=CompetitionJobV2Out)
def competition_analyze_v2(payload: CompetitionAnalyzeRequest, bg: BackgroundTasks, session: Session = Depends(get_session), current_user: User = Depends(get_current_user)):
    public_id = str(uuid.uuid4())
    instas = payload.instagrams or []
    sites = payload.sites or []
    briefing = payload.briefing.model_dump() if payload.briefing else None

    obj = CompetitionAnalysis(
        user_id=current_user.id,
        public_id=public_id,
        instagrams_json=json.dumps(instas, ensure_ascii=False),
        sites_json=json.dumps(sites, ensure_ascii=False),
        company_json=json.dumps(briefing or {}, ensure_ascii=False),
        status="queued",
        stage="Na fila",
        progress=0.0,
    )
    session.add(obj)
    session.commit()
    session.refresh(obj)

    bg.add_task(_run_analysis_job, obj.public_id)

    return CompetitionJobV2Out(
        job_id=obj.public_id,
        report_id=obj.public_id,
        status=obj.status,
        stage=obj.stage,
        progress=obj.progress,
    )


@app.get("/api/competition/jobs/{job_id}", response_model=CompetitionJobV2Out)
def competition_job_v2(job_id: str, session: Session = Depends(get_session), current_user: User = Depends(get_current_user)):
    obj = session.exec(select(CompetitionAnalysis).where(CompetitionAnalysis.public_id == job_id, CompetitionAnalysis.user_id == current_user.id)).first()
    if not obj:
        raise HTTPException(status_code=404, detail="Job não encontrado")
    return CompetitionJobV2Out(
        job_id=obj.public_id,
        report_id=obj.public_id,
        status=obj.status,
        stage=obj.stage,
        progress=obj.progress,
        error=obj.error,
        warning=None
    )


@app.get("/api/competition/reports/{report_id}", response_model=CompetitionReportV2Out)
def competition_report_v2(report_id: str, session: Session = Depends(get_session), current_user: User = Depends(get_current_user)):
    obj = session.exec(select(CompetitionAnalysis).where(CompetitionAnalysis.public_id == report_id, CompetitionAnalysis.user_id == current_user.id)).first()
    if not obj:
        raise HTTPException(status_code=404, detail="Relatório não encontrado")

    if obj.status == "error":
        raise HTTPException(status_code=400, detail=f"Erro no processamento: {obj.error}")

    if obj.status not in ("done", "partial_data"):
        raise HTTPException(status_code=409, detail="Relatório ainda não está pronto")

    try:
        result = json.loads(obj.result_json or "{}")
    except Exception:
        result = {}

    return CompetitionReportV2Out(report_id=obj.public_id, status=obj.status, result=result)


def _normalize_nucleus(nucleus: dict) -> dict:
    def norm(v):
        if v is None:
            return "não informado"
        if isinstance(v, str) and not v.strip():
            return "não informado"
        if isinstance(v, list) and len(v) == 0:
            return "não informado"
        return v

    out = {}
    for k, v in (nucleus or {}).items():
        if isinstance(v, dict):
            out[k] = {kk: norm(vv) for kk, vv in v.items()}
        else:
            out[k] = norm(v)
    return out


@app.get("/api/authority-agents/history", response_model=AuthorityAgentHistoryOut)
def authority_agents_history(client_id: str, session: Session = Depends(get_session), current_user: User = Depends(get_current_user)):
    items = session.exec(
        select(AuthorityAgentRun)
        .where(AuthorityAgentRun.user_id == current_user.id)
        .order_by(AuthorityAgentRun.created_at.desc())
        .limit(50)
    ).all()

    return {
        "items": [
            {
                "id": r.id,
                "agent_key": r.agent_key,
                "output_text": r.output_text,
                "created_at": r.created_at.isoformat(),
            }
            for r in items
        ]
    }


@app.get("/api/authority-agents/run/{run_id}", response_model=AuthorityAgentRunOut)
def authority_agents_get_run(run_id: int, client_id: str, session: Session = Depends(get_session), current_user: User = Depends(get_current_user)):
    run = session.get(AuthorityAgentRun, run_id)
    if not run:
        raise HTTPException(status_code=404, detail="Execução não encontrada.")
    if run.user_id != current_user.id:
        raise HTTPException(status_code=403, detail="Acesso negado para esta execução.")
    return {
        "id": run.id,
        "agent_key": run.agent_key,
        "output_text": run.output_text,
        "created_at": run.created_at.isoformat(),
    }


@app.patch("/api/authority-agents/run/{run_id}", response_model=AuthorityAgentRunOut)
def authority_agents_update_run(run_id: int, payload: dict, session: Session = Depends(get_session), current_user: User = Depends(get_current_user)):
    run = session.get(AuthorityAgentRun, run_id)
    if not run:
        raise HTTPException(status_code=404, detail="Execução não encontrada.")
    if run.user_id != current_user.id:
        raise HTTPException(status_code=403, detail="Acesso negado para esta execução.")

    if "output_text" in payload:
        run.output_text = payload["output_text"]
        session.add(run)
        session.commit()
        session.refresh(run)

    return {
        "id": run.id,
        "agent_key": run.agent_key,
        "output_text": run.output_text,
        "created_at": run.created_at.isoformat(),
    }


@app.post("/api/authority-agents/run", response_model=AuthorityAgentRunOut)
def authority_agents_run(payload: AuthorityAgentRunIn, session: Session = Depends(get_session), current_user: User = Depends(get_current_user)):
    if current_user.credits < 5:
        raise HTTPException(status_code=403, detail="Créditos insuficientes. Precisas de 5 créditos para executar o agente de autoridade.")

    nucleus = _normalize_nucleus(payload.nucleus)

    global_robot = session.exec(select(Robot).where(Robot.public_id == "business-core-global")).first()
    if global_robot:
        core = session.exec(select(BusinessCore).where(BusinessCore.robot_id == global_robot.id)).first()
        if core and getattr(core, "knowledge_text", None):
            nucleus["conhecimento_anexado"] = core.knowledge_text

    try:
        output = run_authority_agent(payload.agent_key, nucleus)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

    current_user.credits -= 5
    session.add(current_user)

    run = AuthorityAgentRun(
        user_id=current_user.id,
        client_id=payload.client_id,
        agent_key=payload.agent_key,
        nucleus_json=json.dumps(nucleus, ensure_ascii=False),
        output_text=output,
    )
    session.add(run)
    session.commit()
    session.refresh(run)

    return {
        "id": run.id,
        "agent_key": run.agent_key,
        "output_text": run.output_text,
        "created_at": run.created_at.isoformat(),
    }


@app.post("/api/robots/{public_id}/authority-agents/run", response_model=AuthorityAgentRunOut)
def authority_agents_run_compat(public_id: str, payload: AuthorityAgentRunIn, session: Session = Depends(get_session), current_user: User = Depends(get_current_user)):
    return authority_agents_run(payload, session, current_user)


@app.get("/api/robots/{public_id}/authority-agents/cooldown")
def authority_agents_cooldown(public_id: str, agent_key: str, client_id: str = "", session: Session = Depends(get_session), current_user: User = Depends(get_current_user)):
    return {"cooldown_seconds": 0}


@app.post("/api/robots/{public_id}/upload-knowledge", response_model=RobotDetail)
async def upload_robot_knowledge(
    public_id: str,
    file: UploadFile = File(...),
    session: Session = Depends(get_session),
    current_user: User = Depends(get_current_user)
):
    robot = _get_robot_or_404(public_id, session, current_user)

    text = await extract_text_from_file(file)
    if not text:
        raise HTTPException(status_code=400, detail="Ficheiro vazio ou sem texto legível.")

    separator = f"\n\n=== CONTEÚDO DO FICHEIRO: {file.filename} ===\n"
    robot.system_instructions += f"{separator}{text}"

    try:
        files_list = json.loads(robot.knowledge_files_json or "[]")
    except Exception:
        files_list = []

    files_list.append({"filename": file.filename, "uploaded_at": datetime.utcnow().isoformat()})
    robot.knowledge_files_json = json.dumps(files_list, ensure_ascii=False)

    session.add(robot)
    session.commit()
    session.refresh(robot)

    return RobotDetail(
        public_id=robot.public_id,
        title=robot.title,
        description=robot.description or "",
        avatar_data=robot.avatar_data,
        system_instructions=robot.system_instructions,
        created_at=robot.created_at.isoformat(),
        knowledge_files_json=robot.knowledge_files_json
    )


@app.delete("/api/robots/{public_id}/knowledge-files/{filename}")
def delete_robot_file(public_id: str, filename: str, session: Session = Depends(get_session), current_user: User = Depends(get_current_user)):
    robot = _get_robot_or_404(public_id, session, current_user)
    try:
        files_list = json.loads(robot.knowledge_files_json or "[]")
    except Exception:
        files_list = []

    new_list = [f for f in files_list if f.get("filename") != filename]
    robot.knowledge_files_json = json.dumps(new_list, ensure_ascii=False)

    if robot.system_instructions:
        pattern = rf"\n\n=== CONTEÚDO DO FICHEIRO: {re.escape(filename)} ===\n.*?(?=\n\n=== CONTEÚDO DO FICHEIRO:|$)"
        robot.system_instructions = re.sub(pattern, "", robot.system_instructions, flags=re.DOTALL)

    session.add(robot)
    session.commit()
    return {"ok": True}


@app.post("/api/robots/{public_id}/business-core/upload-knowledge")
async def upload_business_core_knowledge(
    public_id: str,
    file: UploadFile = File(...),
    session: Session = Depends(get_session),
    current_user: User = Depends(get_current_user)
):
    robot = _get_robot_or_404(public_id, session, current_user)
    core = session.exec(select(BusinessCore).where(BusinessCore.robot_id == robot.id)).first()

    if not core:
        core = BusinessCore(robot_id=robot.id)
        session.add(core)

    text = await extract_text_from_file(file)
    if not text:
        raise HTTPException(status_code=400, detail="Ficheiro vazio ou sem texto.")

    current_knowledge = getattr(core, 'knowledge_text', '') or ""
    separator = f"\n\n=== MATERIAIS DE APOIO: {file.filename} ===\n"
    core.knowledge_text = f"{current_knowledge}{separator}{text}"

    try:
        files_list = json.loads(core.knowledge_files_json or "[]")
    except Exception:
        files_list = []

    files_list.append({"filename": file.filename, "uploaded_at": datetime.utcnow().isoformat()})
    core.knowledge_files_json = json.dumps(files_list, ensure_ascii=False)

    core.updated_at = datetime.utcnow()
    session.add(core)
    session.commit()
    session.refresh(core)

    return core


@app.delete("/api/robots/{public_id}/business-core/files/{filename}")
def delete_business_core_file(public_id: str, filename: str, session: Session = Depends(get_session), current_user: User = Depends(get_current_user)):
    robot = _get_robot_or_404(public_id, session, current_user)
    core = session.exec(select(BusinessCore).where(BusinessCore.robot_id == robot.id)).first()

    if not core:
        raise HTTPException(status_code=404, detail="Núcleo não encontrado")

    try:
        files_list = json.loads(core.knowledge_files_json or "[]")
    except Exception:
        files_list = []

    new_list = [f for f in files_list if f.get("filename") != filename]
    core.knowledge_files_json = json.dumps(new_list, ensure_ascii=False)

    if getattr(core, 'knowledge_text', None):
        pattern = rf"\n\n=== MATERIAIS DE APOIO: {re.escape(filename)} ===\n.*?(?=\n\n=== MATERIAIS DE APOIO:|$)"
        core.knowledge_text = re.sub(pattern, "", core.knowledge_text, flags=re.DOTALL)

    session.add(core)
    session.commit()
    return {"ok": True}


@app.post("/api/authority-agents/suggest-themes")
def authority_agents_suggest_themes(payload: SuggestThemesRequest, session: Session = Depends(get_session), current_user: User = Depends(get_current_user)):
    if current_user.credits < 2:
        raise HTTPException(status_code=403, detail="Créditos insuficientes. Precisas de 2 créditos para gerar temas com IA.")

    from .ai import suggest_themes_for_task
    try:
        themes = suggest_themes_for_task(payload.agent_key, payload.nucleus, payload.task)

        current_user.credits -= 2
        session.add(current_user)
        session.commit()

        return {"themes": themes}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# ==========================================
# ROTAS DO LINKEDIN OAUTH2
# ==========================================

@app.get("/api/linkedin/auth-url")
def get_linkedin_auth_url(current_user: User = Depends(get_current_user)):
    scopes = "w_member_social openid profile email"
    params = {
        "response_type": "code",
        "client_id": LINKEDIN_CLIENT_ID,
        "redirect_uri": LINKEDIN_REDIRECT_URI,
        "state": uuid.uuid4().hex,
        "scope": scopes
    }
    url = f"https://www.linkedin.com/oauth/v2/authorization?{urlencode(params)}"
    return {"url": url}


@app.post("/api/linkedin/connect")
async def connect_linkedin(payload: LinkedInConnectIn, session: Session = Depends(get_session), current_user: User = Depends(get_current_user)):
    token_url = "https://www.linkedin.com/oauth/v2/accessToken"
    data = {
        "grant_type": "authorization_code",
        "code": payload.code,
        "client_id": LINKEDIN_CLIENT_ID,
        "client_secret": LINKEDIN_CLIENT_SECRET,
        "redirect_uri": LINKEDIN_REDIRECT_URI
    }

    async with httpx.AsyncClient() as client:
        resp = await client.post(token_url, data=data)
        if resp.status_code != 200:
            raise HTTPException(status_code=400, detail=f"Erro ao ligar ao LinkedIn: {resp.text}")

        token_data = resp.json()
        access_token = token_data.get("access_token")
        expires_in = token_data.get("expires_in", 0)

        profile_url = "https://api.linkedin.com/v2/userinfo"
        headers = {"Authorization": f"Bearer {access_token}"}
        prof_resp = await client.get(profile_url, headers=headers)

        if prof_resp.status_code != 200:
            raise HTTPException(status_code=400, detail=f"Erro ao obter perfil: {prof_resp.text}")

        prof_data = prof_resp.json()
        linkedin_urn = f"urn:li:person:{prof_data.get('sub')}"

        current_user.linkedin_access_token = access_token
        current_user.linkedin_token_expires_at = datetime.utcnow() + timedelta(seconds=expires_in)
        current_user.linkedin_urn = linkedin_urn

        session.add(current_user)
        session.commit()

        return {"ok": True, "message": "Conta do LinkedIn conectada com sucesso!"}


@app.post("/api/linkedin/publish")
async def publish_linkedin(payload: dict, session: Session = Depends(get_session), current_user: User = Depends(get_current_user)):
    if not current_user.linkedin_access_token or not current_user.linkedin_urn:
        raise HTTPException(status_code=400, detail="LinkedIn não está conectado nesta conta.")

    url = "https://api.linkedin.com/v2/ugcPosts"
    headers = {
        "Authorization": f"Bearer {current_user.linkedin_access_token}",
        "X-Restli-Protocol-Version": "2.0.0",
        "Content-Type": "application/json"
    }

    data = {
        "author": current_user.linkedin_urn,
        "lifecycleState": "PUBLISHED",
        "specificContent": {
            "com.linkedin.ugc.ShareContent": {
                "shareCommentary": {"text": payload.get("text")},
                "shareMediaCategory": "NONE"
            }
        },
        "visibility": {"com.linkedin.ugc.MemberNetworkVisibility": "PUBLIC"}
    }

    async with httpx.AsyncClient() as client:
        resp = await client.post(url, headers=headers, json=data)
        if resp.status_code != 201:
            raise HTTPException(status_code=400, detail=f"Erro da API do LinkedIn: {resp.text}")

    return {"ok": True}


# ==========================================
# HELPERS DO MOTOR DE IMAGEM V3
# ==========================================

OPENAI_CHAT_MODEL = "gpt-5.4"
OPENAI_IMAGE_MODEL = "gpt-image-1.5"

GEMINI_NATIVE_PRO_MODEL = "gemini-3-pro-image-preview"
GEMINI_NATIVE_FAST_MODEL = "gemini-3.1-flash-image-preview"
GOOGLE_IMAGEN_MODEL = "imagen-4.0-ultra-generate-001"

FAL_MODEL_PATH = "fal-ai/flux-pro/v1.1-ultra"

HTTP_TIMEOUT = httpx.Timeout(connect=20.0, read=180.0, write=60.0, pool=60.0)


def _sse(data: Dict[str, Any]) -> str:
    return f"data: {json.dumps(data, ensure_ascii=False)}\n\n"


def _clamp_text(text: str, max_len: int = 7000) -> str:
    if not text:
        return ""
    text = re.sub(r"\s+", " ", text).strip()
    return text[:max_len]


def _parse_json_safe(text: str) -> Dict[str, Any]:
    try:
        return json.loads(text)
    except Exception:
        cleaned = text.strip()
        cleaned = re.sub(r"^```json\s*", "", cleaned)
        cleaned = re.sub(r"\s*```$", "", cleaned)
        return json.loads(cleaned)


def _data_uri_from_b64(b64_data: str, mime: str = "image/png") -> str:
    return f"data:{mime};base64,{b64_data}"


def _openai_size_from_aspect_ratio(ar: str) -> str:
    if ar == "9:16":
        return "1024x1536"
    if ar == "16:9":
        return "1536x1024"
    return "1024x1024"


def _infer_asset_type(user_prompt: str) -> str:
    p = user_prompt.lower()

    if "carrossel" in p and ("capa" in p or "slide 1" in p):
        return "carousel_cover"
    if "carrossel" in p:
        return "carousel_internal"
    if any(x in p for x in ["story", "stories"]):
        return "story_cta"
    if any(x in p for x in ["banner", "landing page", "hero"]):
        return "landing_banner"
    if any(x in p for x in ["thumbnail", "thumb", "youtube", "capa de vídeo", "capa de reels"]):
        return "thumbnail"
    if any(x in p for x in ["feed", "post", "instagram", "publicitária", "publicitario", "anúncio", "anuncio", "criativo"]):
        return "feed_offer"
    return "generic_ad"


def _infer_aspect_ratio(user_prompt: str, asset_type: str) -> str:
    p = user_prompt.lower()

    if any(x in p for x in ["9:16", "vertical", "story", "stories", "shorts", "reels"]):
        return "9:16"
    if any(x in p for x in ["16:9", "horizontal", "banner", "landing page", "hero", "thumbnail", "youtube"]):
        return "16:9"

    if asset_type in ("story_cta",):
        return "9:16"
    if asset_type in ("landing_banner", "thumbnail"):
        return "16:9"

    return "1:1"


def _marketing_preset(asset_type: str) -> Dict[str, str]:
    presets = {
        "feed_offer": {
            "mode": "direct_response",
            "goal": "promotional social media ad",
            "layout": "strong focal point, clean headline zone at top, subheadline zone in middle, CTA-safe area near bottom, balanced negative space, premium promotional composition",
            "style": "premium commercial design, modern social media ad, clean contrast, marketing-first visual",
            "overlay": "headline top, support line mid, CTA bottom",
            "grid": "12-column square ad grid with 6-8 percent safe margins",
        },
        "story_cta": {
            "mode": "lead_generation",
            "goal": "vertical conversion story creative",
            "layout": "tall mobile-first composition, strong center focal point, headline zone upper third, support zone center, CTA zone lower third, clean safe margins",
            "style": "high-contrast vertical promo, polished mobile ad, fast readability",
            "overlay": "headline upper third, support line center, CTA lower third",
            "grid": "vertical social story grid with generous top and bottom safe areas",
        },
        "carousel_cover": {
            "mode": "carousel_visual",
            "goal": "carousel opening slide",
            "layout": "bold editorial composition, large hook area, memorable cover structure, strong hero image and controlled whitespace",
            "style": "clean branded editorial look, premium post design, high scroll-stopping clarity",
            "overlay": "big title zone, optional short subline, clear visual anchor",
            "grid": "editorial cover grid with strong headline block and clean balance",
        },
        "carousel_internal": {
            "mode": "carousel_visual",
            "goal": "carousel educational internal slide",
            "layout": "structured composition with room for title and short blocks, clean support visual, organized hierarchy, no empty dead zones",
            "style": "clean educational marketing layout, practical and legible visual support",
            "overlay": "title area plus short supporting blocks",
            "grid": "modular educational slide grid with defined text and visual zones",
        },
        "landing_banner": {
            "mode": "premium_branding",
            "goal": "landing page hero banner",
            "layout": "wide hero layout, subject balanced to one side, large copy space, strong headline and CTA zones, premium web hero composition",
            "style": "trustworthy commercial branding, modern landing page visual, polished premium look",
            "overlay": "headline block, subheadline block, CTA block",
            "grid": "wide hero grid with large reserved copy panel",
        },
        "thumbnail": {
            "mode": "social_media_post",
            "goal": "thumbnail or cover image",
            "layout": "clear subject emphasis, bold hierarchy, high contrast, simple background, minimal clutter",
            "style": "click-focused composition, strong content-first design",
            "overlay": "short bold title area only",
            "grid": "thumbnail grid with dominant focal point and bold title zone",
        },
        "generic_ad": {
            "mode": "direct_response",
            "goal": "general advertising creative",
            "layout": "clean promotional layout, headline-safe area, support-safe area, CTA-safe area, strong hierarchy",
            "style": "modern commercial marketing image, premium but practical",
            "overlay": "title, support text, CTA",
            "grid": "balanced ad grid with reserved text panels",
        },
    }
    return presets.get(asset_type, presets["generic_ad"])


def _detect_offer_intent(user_prompt: str) -> bool:
    p = user_prompt.lower()
    keywords = [
        "inscrever", "inscrição", "vagas", "evento", "curso", "imersão", "imersao",
        "mentoria", "whatsapp", "chamar", "cta", "promoção", "promocao", "desconto",
        "lançamento", "lancamento", "fechar", "comprar", "lead", "cadastro"
    ]
    return any(k in p for k in keywords)


def _extract_quoted_copy(user_prompt: str) -> List[str]:
    quoted = re.findall(r'"([^"]+)"', user_prompt)
    quoted += re.findall(r"'([^']+)'", user_prompt)
    return [q.strip() for q in quoted if q.strip()]


async def _post_json_with_retry(
    client: httpx.AsyncClient,
    url: str,
    headers: Dict[str, str],
    json_payload: Dict[str, Any],
    retries: int = 3,
    backoff_base: float = 1.2,
) -> httpx.Response:
    last_exc = None

    for attempt in range(1, retries + 1):
        try:
            resp = await client.post(url, headers=headers, json=json_payload)
            if resp.status_code < 400:
                return resp

            if resp.status_code not in (429, 500, 502, 503, 504):
                raise httpx.HTTPStatusError(
                    f"HTTP {resp.status_code}: {resp.text}",
                    request=resp.request,
                    response=resp,
                )

            last_exc = httpx.HTTPStatusError(
                f"HTTP {resp.status_code}: {resp.text}",
                request=resp.request,
                response=resp,
            )

        except Exception as e:
            last_exc = e

        if attempt < retries:
            await asyncio.sleep(backoff_base * attempt)

    raise last_exc if last_exc else RuntimeError("Falha desconhecida em _post_json_with_retry")


async def _improve_prompt_with_openai(
    client: httpx.AsyncClient,
    user_prompt: str,
    aspect_ratio: str,
    asset_type: str,
    preset: Dict[str, str],
    openai_key: str,
) -> Dict[str, str]:
    headers = {
        "Authorization": f"Bearer {openai_key}",
        "Content-Type": "application/json",
    }

    has_offer_intent = _detect_offer_intent(user_prompt)
    quoted_copy = _extract_quoted_copy(user_prompt)
    exact_copy_mode = "yes" if quoted_copy else "no"

    system_text = """
You are a world-class performance marketing art director, advertising designer, and visual layout strategist.

Your job is NOT to create an artistic AI image.
Your job is to create a prompt for a HIGH-PERFORMING MARKETING CREATIVE with strong layout discipline.

Return STRICT JSON only with this exact shape:
{
  "prompt_en": string,
  "negative_prompt_en": string,
  "creative_direction": string,
  "layout_notes": string,
  "marketing_mode": string,
  "overlay_recommendation": string,
  "design_system": string,
  "grid_spec": string,
  "text_distribution_rules": string,
  "copy_policy": string
}

Critical layout rules:
1. Prioritize ad layout quality over cinematic beauty.
2. The image must feel usable for real advertising, carousel, feed, story, thumbnail, or landing page design.
3. Create strong composition discipline:
   - clear grid
   - safe margins
   - no giant empty dead zones
   - no overcrowding
   - no awkward tiny text islands
   - no oversized text dominance unless it is a thumbnail
4. The image must include reserved visual zones for:
   - headline
   - subheadline or supporting text
   - CTA
5. Keep text distribution proportional.
6. If the user did NOT provide exact copy, do NOT invent long text paragraphs inside the image.
7. If the user did provide exact copy in quotes, respect it but recommend short lines and balanced placement.
8. Prefer:
   - clean headline panel
   - subheadline panel
   - CTA button/pill area
   - brand-safe negative space
   - balanced commercial composition
9. Negative prompt must suppress:
   - unreadable text
   - random letters
   - bad typography
   - distorted spacing
   - clutter
   - warped anatomy
   - ugly graphic balance
   - dead space
   - extra fingers
   - watermark
   - duplicated objects
10. marketing_mode must be one of:
   - direct_response
   - premium_branding
   - social_media_post
   - carousel_visual
   - event_promo
   - lead_generation
11. text_distribution_rules should explicitly define:
   - max headline lines
   - max subheadline lines
   - CTA placement
   - safe margins
   - text balance
12. copy_policy should explicitly say one of:
   - use_exact_copy
   - ultra_short_copy_only
   - reserve_text_zones_without_long_copy
"""

    user_text = (
        f"User prompt: {user_prompt}\n"
        f"Asset type: {asset_type}\n"
        f"Aspect ratio: {aspect_ratio}\n"
        f"Preset goal: {preset['goal']}\n"
        f"Preset layout: {preset['layout']}\n"
        f"Preset style: {preset['style']}\n"
        f"Preset overlay: {preset['overlay']}\n"
        f"Preset grid: {preset['grid']}\n"
        f"Strong conversion intent present: {'yes' if has_offer_intent else 'no'}\n"
        f"Exact quoted copy provided: {exact_copy_mode}\n"
        f"Quoted copy list: {quoted_copy}\n"
        "Return valid JSON only."
    )

    payload = {
        "model": OPENAI_CHAT_MODEL,
        "response_format": {"type": "json_object"},
        "messages": [
            {"role": "system", "content": system_text},
            {"role": "user", "content": user_text},
        ],
        "temperature": 0.25,
    }

    resp = await _post_json_with_retry(
        client=client,
        url="https://api.openai.com/v1/chat/completions",
        headers=headers,
        json_payload=payload,
        retries=3,
    )

    content = resp.json()["choices"][0]["message"]["content"]
    data = _parse_json_safe(content)

    return {
        "prompt_en": _clamp_text(data.get("prompt_en", "")),
        "negative_prompt_en": _clamp_text(data.get("negative_prompt_en", "")),
        "creative_direction": _clamp_text(data.get("creative_direction", "")),
        "layout_notes": _clamp_text(data.get("layout_notes", "")),
        "marketing_mode": _clamp_text(data.get("marketing_mode", "")),
        "overlay_recommendation": _clamp_text(data.get("overlay_recommendation", "")),
        "design_system": _clamp_text(data.get("design_system", "")),
        "grid_spec": _clamp_text(data.get("grid_spec", "")),
        "text_distribution_rules": _clamp_text(data.get("text_distribution_rules", "")),
        "copy_policy": _clamp_text(data.get("copy_policy", "")),
    }


def _build_final_generation_prompt(
    prompt_en: str,
    creative_direction: str,
    layout_notes: str,
    marketing_mode: str,
    overlay_recommendation: str,
    design_system: str,
    grid_spec: str,
    text_distribution_rules: str,
    copy_policy: str,
    preset: Dict[str, str],
    asset_type: str,
    aspect_ratio: str,
    original_prompt: str,
) -> str:
    conversion_boost = ""
    if _detect_offer_intent(original_prompt):
        conversion_boost = """
Additional conversion priorities:
- ad-ready promotional structure
- immediate readability
- high scroll-stopping clarity
- trustworthy business tone
- clear conversion-oriented hierarchy
- strong CTA-safe area
"""

    quoted_copy = _extract_quoted_copy(original_prompt)
    copy_clause = ""
    if quoted_copy:
        copy_clause = f"""
Exact copy provided by user:
{quoted_copy}

Use the exact user copy only if it fits the layout elegantly.
Break long lines intelligently.
Do not stretch text awkwardly.
Do not create disproportional text blocks.
"""
    else:
        copy_clause = """
No exact copy was provided by the user.
Do not invent long body copy.
Prefer clean layout zones, short marketing placeholders, or minimal ultra-short text treatment only.
"""

    final_prompt = f"""
{prompt_en}

This image must look like a high-performing marketing creative with disciplined design layout.

Primary objective:
{preset['goal']}

Required layout behavior:
{preset['layout']}

Required visual style:
{preset['style']}

Creative direction:
{creative_direction}

Layout notes:
{layout_notes}

Overlay recommendation:
{overlay_recommendation}

Design system:
{design_system}

Grid specification:
{grid_spec}

Text distribution rules:
{text_distribution_rules}

Copy policy:
{copy_policy}

Mandatory design constraints:
- strong visual hierarchy
- premium commercial polish
- no giant dead spaces
- no awkward empty corners
- no cramped areas
- balanced composition
- consistent spacing
- reserved headline zone
- reserved subheadline zone
- reserved CTA zone
- safe margins around the composition
- marketing-ready layout
- usable as real ad creative
- clean social media readability
- no chaotic text scattering
- no oversized or undersized text imbalance

Asset type: {asset_type}
Aspect ratio: {aspect_ratio}

{copy_clause}

{conversion_boost}
"""
    return _clamp_text(final_prompt, 7000)


async def _generate_openai_image(
    client: httpx.AsyncClient,
    final_prompt: str,
    aspect_ratio: str,
    openai_key: str,
) -> Dict[str, Any]:
    headers = {
        "Authorization": f"Bearer {openai_key}",
        "Content-Type": "application/json",
    }

    size = _openai_size_from_aspect_ratio(aspect_ratio)

    payload = {
        "model": OPENAI_IMAGE_MODEL,
        "prompt": final_prompt,
        "size": size,
        "quality": "high",
        "output_format": "png",
        "background": "opaque",
    }

    resp = await _post_json_with_retry(
        client=client,
        url="https://api.openai.com/v1/images/generations",
        headers=headers,
        json_payload=payload,
        retries=3,
    )

    body = resp.json()
    data = body.get("data", [])
    if not data:
        raise ValueError(f"OpenAI sem data: {body}")

    first = data[0]
    b64_json = first.get("b64_json")
    if not b64_json:
        raise ValueError(f"OpenAI não retornou b64_json: {body}")

    return {
        "engine_id": "openai",
        "motor": "OpenAI GPT Image 1.5",
        "url": _data_uri_from_b64(b64_json, "image/png"),
        "raw": body,
    }


async def _generate_flux_image(
    client: httpx.AsyncClient,
    final_prompt: str,
    negative_prompt_en: str,
    aspect_ratio: str,
    fal_key: str,
) -> Dict[str, Any]:
    headers = {
        "Authorization": f"Key {fal_key}",
        "Content-Type": "application/json",
    }

    payload = {
        "prompt": final_prompt,
        "negative_prompt": negative_prompt_en or None,
        "aspect_ratio": aspect_ratio,
        "num_images": 1,
        "output_format": "jpeg",
        "safety_tolerance": 2,
    }

    resp = await _post_json_with_retry(
        client=client,
        url=f"https://fal.run/{FAL_MODEL_PATH}",
        headers=headers,
        json_payload=payload,
        retries=3,
    )

    body = resp.json()
    images = body.get("images", [])
    if not images or not images[0].get("url"):
        raise ValueError(f"FLUX não retornou URL válida: {body}")

    return {
        "engine_id": "flux",
        "motor": "FLUX 1.1 Pro Ultra",
        "url": images[0]["url"],
        "raw": body,
    }


def _extract_gemini_inline_image(response_json: Dict[str, Any]) -> Optional[str]:
    candidates = response_json.get("candidates", [])
    for candidate in candidates:
        content = candidate.get("content", {})
        parts = content.get("parts", [])
        for part in parts:
            inline_data = part.get("inlineData") or part.get("inline_data")
            if inline_data and inline_data.get("data"):
                mime = inline_data.get("mimeType") or inline_data.get("mime_type") or "image/png"
                return _data_uri_from_b64(inline_data["data"], mime)
    return None


async def _generate_google_native_image(
    client: httpx.AsyncClient,
    final_prompt: str,
    aspect_ratio: str,
    gemini_key: str,
    model_name: str,
) -> Dict[str, Any]:
    if not gemini_key:
        raise ValueError("GEMINI_API_KEY não configurada.")

    headers = {
        "x-goog-api-key": gemini_key,
        "Content-Type": "application/json",
    }

    url = f"https://generativelanguage.googleapis.com/v1beta/models/{model_name}:generateContent"

    payload = {
        "contents": [{
            "role": "user",
            "parts": [
                {"text": final_prompt}
            ]
        }],
        "generationConfig": {
            "responseModalities": ["IMAGE"],
            "imageConfig": {
                "aspectRatio": aspect_ratio,
                "imageSize": "2K"
            }
        }
    }

    resp = await _post_json_with_retry(
        client=client,
        url=url,
        headers=headers,
        json_payload=payload,
        retries=3,
    )

    body = resp.json()
    data_uri = _extract_gemini_inline_image(body)
    if not data_uri:
        raise ValueError(f"{model_name} não retornou inline image válida: {body}")

    pretty_name = "Google Nano Banana Pro" if model_name == GEMINI_NATIVE_PRO_MODEL else "Google Nano Banana 2"

    return {
        "engine_id": "google",
        "motor": pretty_name,
        "google_model": model_name,
        "url": data_uri,
        "raw": body,
    }


async def _generate_google_imagen_image(
    client: httpx.AsyncClient,
    final_prompt: str,
    aspect_ratio: str,
    gemini_key: str,
) -> Dict[str, Any]:
    if not gemini_key:
        raise ValueError("GEMINI_API_KEY não configurada.")

    headers = {
        "x-goog-api-key": gemini_key,
        "Content-Type": "application/json",
    }

    url = f"https://generativelanguage.googleapis.com/v1beta/models/{GOOGLE_IMAGEN_MODEL}:predict"

    payload = {
        "instances": [
            {
                "prompt": final_prompt
            }
        ],
        "parameters": {
            "sampleCount": 1,
            "aspectRatio": aspect_ratio,
            "imageSize": "2K",
            "personGeneration": "allow_adult",
        }
    }

    resp = await _post_json_with_retry(
        client=client,
        url=url,
        headers=headers,
        json_payload=payload,
        retries=3,
    )

    body = resp.json()
    predictions = body.get("predictions", [])
    if not predictions:
        raise ValueError(f"Google Imagen sem predictions: {body}")

    pred = predictions[0]
    base64_img = pred.get("bytesBase64Encoded")
    if not base64_img:
        raise ValueError(f"Google Imagen sem bytesBase64Encoded: {body}")

    return {
        "engine_id": "google",
        "motor": "Google Imagen 4 Ultra",
        "google_model": GOOGLE_IMAGEN_MODEL,
        "url": _data_uri_from_b64(base64_img, "image/png"),
        "raw": body,
    }


async def _generate_google_best_available(
    client: httpx.AsyncClient,
    final_prompt: str,
    aspect_ratio: str,
    gemini_key: str,
) -> Dict[str, Any]:
    errors = []

    try:
        return await _generate_google_native_image(
            client=client,
            final_prompt=final_prompt,
            aspect_ratio=aspect_ratio,
            gemini_key=gemini_key,
            model_name=GEMINI_NATIVE_PRO_MODEL,
        )
    except Exception as e:
        errors.append(f"{GEMINI_NATIVE_PRO_MODEL}: {str(e)}")

    try:
        return await _generate_google_native_image(
            client=client,
            final_prompt=final_prompt,
            aspect_ratio=aspect_ratio,
            gemini_key=gemini_key,
            model_name=GEMINI_NATIVE_FAST_MODEL,
        )
    except Exception as e:
        errors.append(f"{GEMINI_NATIVE_FAST_MODEL}: {str(e)}")

    try:
        return await _generate_google_imagen_image(
            client=client,
            final_prompt=final_prompt,
            aspect_ratio=aspect_ratio,
            gemini_key=gemini_key,
        )
    except Exception as e:
        errors.append(f"{GOOGLE_IMAGEN_MODEL}: {str(e)}")

    raise ValueError(" | ".join(errors))


async def _judge_images_with_openai(
    client: httpx.AsyncClient,
    original_prompt: str,
    final_prompt: str,
    creative_direction: str,
    layout_notes: str,
    marketing_mode: str,
    overlay_recommendation: str,
    grid_spec: str,
    text_distribution_rules: str,
    copy_policy: str,
    asset_type: str,
    valid_images: List[Dict[str, Any]],
    openai_key: str,
) -> List[Dict[str, Any]]:
    if not valid_images:
        return []

    headers = {
        "Authorization": f"Bearer {openai_key}",
        "Content-Type": "application/json",
    }

    content: List[Dict[str, Any]] = [
        {
            "type": "text",
            "text": (
                "You are a senior performance marketing creative director and advertising layout critic. "
                "Rank these images by how strong they are as real MARKETING creatives.\n\n"
                f"Original prompt: {original_prompt}\n"
                f"Final generation prompt: {final_prompt}\n"
                f"Creative direction: {creative_direction}\n"
                f"Layout notes: {layout_notes}\n"
                f"Marketing mode: {marketing_mode}\n"
                f"Overlay recommendation: {overlay_recommendation}\n"
                f"Grid spec: {grid_spec}\n"
                f"Text distribution rules: {text_distribution_rules}\n"
                f"Copy policy: {copy_policy}\n"
                f"Asset type: {asset_type}\n\n"
                "Evaluate in this order:\n"
                "1. Marketing usability\n"
                "2. Layout discipline\n"
                "3. Text placement quality\n"
                "4. Balance between text zones and image zones\n"
                "5. Low dead space\n"
                "6. Good hierarchy\n"
                "7. CTA/headline/subheadline proportionality\n"
                "8. Commercial polish\n"
                "9. Low defects\n\n"
                "Do NOT reward cinematic beauty or artistic drama if the layout is worse for marketing.\n\n"
                "Return STRICT JSON ONLY in this exact format:\n"
                "{\"ranking\": [{\"posicao\": 1, \"engine_id\": \"openai\", \"nota\": 9.4, \"justificativa\": \"...\"}]}\n\n"
                "Allowed engine_id values only: openai, flux, google.\n"
                f"You must rank exactly {len(valid_images)} images."
            ),
        }
    ]

    for item in valid_images:
        content.append({
            "type": "text",
            "text": f"Image from engine_id={item['engine_id']} and motor={item['motor']}"
        })
        content.append({
            "type": "image_url",
            "image_url": {"url": item["url"]}
        })

    payload = {
        "model": OPENAI_CHAT_MODEL,
        "response_format": {"type": "json_object"},
        "messages": [{"role": "user", "content": content}],
        "temperature": 0.2,
        "max_completion_tokens": 1400,
    }

    resp = await _post_json_with_retry(
        client=client,
        url="https://api.openai.com/v1/chat/completions",
        headers=headers,
        json_payload=payload,
        retries=2,
    )

    ranking_raw = resp.json()["choices"][0]["message"]["content"]
    parsed = _parse_json_safe(ranking_raw)
    ranking = parsed.get("ranking", [])

    image_map = {img["engine_id"]: img for img in valid_images}
    final_ranking: List[Dict[str, Any]] = []

    for row in ranking:
        engine_id = row.get("engine_id")
        if engine_id not in image_map:
            continue

        img = image_map[engine_id]
        final_ranking.append({
            "posicao": row.get("posicao"),
            "engine_id": engine_id,
            "motor": img["motor"],
            "nota": row.get("nota"),
            "justificativa": row.get("justificativa"),
            "url": img["url"],
        })

    if len(final_ranking) != len(valid_images):
        missing = [img for img in valid_images if img["engine_id"] not in {r["engine_id"] for r in final_ranking}]
        start_pos = len(final_ranking) + 1
        for idx, img in enumerate(missing, start=start_pos):
            final_ranking.append({
                "posicao": idx,
                "engine_id": img["engine_id"],
                "motor": img["motor"],
                "nota": None,
                "justificativa": "Ranking fallback aplicado porque a resposta do avaliador veio incompleta.",
                "url": img["url"],
            })

    final_ranking.sort(key=lambda x: (x["posicao"] if x["posicao"] is not None else 999))
    return final_ranking


# ==========================================
# ROTA: MOTOR DE IMAGEM V3 TOP DE LINHA
# ==========================================

@app.get("/api/image-engine/stream")
async def image_engine_stream(prompt: str, current_user: User = Depends(get_current_user)):
    """
    Motor de imagem V3:
    1. Classifica tipo de peça
    2. Aplica preset de marketing
    3. Refina prompt com foco em grid, diagramação e texto
    4. Gera em paralelo com OpenAI, FLUX e Google
    5. No Google tenta Nano Banana Pro -> Nano Banana 2 -> Imagen 4 Ultra
    6. Rankeia por utilidade comercial e qualidade de layout
    """
    openai_key = os.getenv("OPENAI_API_KEY")
    fal_key = os.getenv("FAL_KEY")
    gemini_key = os.getenv("GEMINI_API_KEY")

    async def event_generator():
        print(f"\n{'='*60}")
        print(f"🚀 [MOTOR DE IMAGEM V3] Iniciado por: {current_user.email}")
        print(f"📝 [PROMPT ORIGINAL]: {prompt}")
        print(f"{'='*60}\n")

        if not openai_key:
            yield _sse({"error": "OPENAI_API_KEY não configurada."})
            return

        if not fal_key:
            yield _sse({"error": "FAL_KEY não configurada."})
            return

        if not gemini_key:
            yield _sse({"error": "GEMINI_API_KEY não configurada."})
            return

        try:
            asset_type = _infer_asset_type(prompt)
            aspect_ratio = _infer_aspect_ratio(prompt, asset_type)
            preset = _marketing_preset(asset_type)

            async with httpx.AsyncClient(timeout=HTTP_TIMEOUT, follow_redirects=True) as client:
                yield _sse({
                    "status": "Analisando briefing com foco em marketing, grid e distribuição de texto...",
                    "progress": 10,
                    "meta": {
                        "asset_type": asset_type,
                        "aspect_ratio": aspect_ratio,
                        "preset_mode": preset["mode"],
                        "preset_goal": preset["goal"],
                    },
                })

                improved = await _improve_prompt_with_openai(
                    client=client,
                    user_prompt=prompt,
                    aspect_ratio=aspect_ratio,
                    asset_type=asset_type,
                    preset=preset,
                    openai_key=openai_key,
                )

                improved_prompt = improved["prompt_en"]
                negative_prompt = improved["negative_prompt_en"]
                creative_direction = improved["creative_direction"]
                layout_notes = improved["layout_notes"]
                marketing_mode = improved["marketing_mode"] or preset["mode"]
                overlay_recommendation = improved["overlay_recommendation"]
                design_system = improved["design_system"]
                grid_spec = improved["grid_spec"]
                text_distribution_rules = improved["text_distribution_rules"]
                copy_policy = improved["copy_policy"]

                final_prompt = _build_final_generation_prompt(
                    prompt_en=improved_prompt,
                    creative_direction=creative_direction,
                    layout_notes=layout_notes,
                    marketing_mode=marketing_mode,
                    overlay_recommendation=overlay_recommendation,
                    design_system=design_system,
                    grid_spec=grid_spec,
                    text_distribution_rules=text_distribution_rules,
                    copy_policy=copy_policy,
                    preset=preset,
                    asset_type=asset_type,
                    aspect_ratio=aspect_ratio,
                    original_prompt=prompt,
                )

                print(f"🎯 [ASSET TYPE]: {asset_type}")
                print(f"📐 [ASPECT RATIO]: {aspect_ratio}")
                print(f"📣 [PRESET MODE]: {preset['mode']}")
                print(f"🧠 [PROMPT BASE]: {improved_prompt}")
                print(f"🧼 [NEGATIVE PROMPT]: {negative_prompt}")
                print(f"🎨 [CREATIVE DIRECTION]: {creative_direction}")
                print(f"📏 [LAYOUT NOTES]: {layout_notes}")
                print(f"🪄 [OVERLAY]: {overlay_recommendation}")
                print(f"🧩 [DESIGN SYSTEM]: {design_system}")
                print(f"📊 [GRID SPEC]: {grid_spec}")
                print(f"🔤 [TEXT RULES]: {text_distribution_rules}")
                print(f"📝 [COPY POLICY]: {copy_policy}")
                print(f"🚀 [FINAL PROMPT]: {final_prompt}\n")

                yield _sse({
                    "status": "Briefing refinado. Gerando peças nas 3 engines...",
                    "progress": 24,
                    "asset_type": asset_type,
                    "aspect_ratio": aspect_ratio,
                    "marketing_mode": marketing_mode,
                    "preset": preset,
                    "improved_prompt": improved_prompt,
                    "negative_prompt": negative_prompt,
                    "creative_direction": creative_direction,
                    "layout_notes": layout_notes,
                    "overlay_recommendation": overlay_recommendation,
                    "design_system": design_system,
                    "grid_spec": grid_spec,
                    "text_distribution_rules": text_distribution_rules,
                    "copy_policy": copy_policy,
                    "final_prompt": final_prompt,
                })

                tasks = [
                    asyncio.create_task(_generate_openai_image(client, final_prompt, aspect_ratio, openai_key)),
                    asyncio.create_task(_generate_flux_image(client, final_prompt, negative_prompt, aspect_ratio, fal_key)),
                    asyncio.create_task(_generate_google_best_available(client, final_prompt, aspect_ratio, gemini_key)),
                ]

                completed_results: List[Dict[str, Any]] = []
                engine_errors: List[Dict[str, Any]] = []

                total = len(tasks)
                done_count = 0

                for coro in asyncio.as_completed(tasks):
                    try:
                        result = await coro
                        completed_results.append(result)
                        done_count += 1

                        yield _sse({
                            "status": f"Peça gerada com sucesso em {result['motor']}.",
                            "progress": 24 + int((done_count / total) * 46),
                            "partial_result": {
                                "engine_id": result["engine_id"],
                                "motor": result["motor"],
                                "url": result["url"],
                            },
                            "completed": done_count,
                            "total": total,
                        })

                        print(f"✅ [SUCESSO] {result['motor']} gerou imagem.")

                    except Exception as e:
                        done_count += 1
                        err_msg = str(e)
                        engine_errors.append({"erro": err_msg})
                        print(f"❌ [ERRO] Engine falhou: {err_msg}")

                        yield _sse({
                            "status": "Uma das engines falhou, mas o pipeline continua...",
                            "progress": 24 + int((done_count / total) * 46),
                            "warning": err_msg,
                            "completed": done_count,
                            "total": total,
                        })

                valid_images = [r for r in completed_results if r.get("url")]

                if not valid_images:
                    raise RuntimeError("Nenhuma engine conseguiu gerar imagem válida.")

                yield _sse({
                    "status": f"{len(valid_images)} peça(s) válidas geradas. Avaliando qual funciona melhor para marketing e layout...",
                    "progress": 78,
                    "generated_count": len(valid_images),
                    "errors_count": len(engine_errors),
                })

                final_ranking = await _judge_images_with_openai(
                    client=client,
                    original_prompt=prompt,
                    final_prompt=final_prompt,
                    creative_direction=creative_direction,
                    layout_notes=layout_notes,
                    marketing_mode=marketing_mode,
                    overlay_recommendation=overlay_recommendation,
                    grid_spec=grid_spec,
                    text_distribution_rules=text_distribution_rules,
                    copy_policy=copy_policy,
                    asset_type=asset_type,
                    valid_images=valid_images,
                    openai_key=openai_key,
                )

                print("🏆 [RANKING FINAL V3]")
                print(json.dumps(final_ranking, indent=2, ensure_ascii=False))

                yield _sse({
                    "status": "Concluído!",
                    "progress": 100,
                    "asset_type": asset_type,
                    "aspect_ratio": aspect_ratio,
                    "marketing_mode": marketing_mode,
                    "preset": preset,
                    "improved_prompt": improved_prompt,
                    "negative_prompt": negative_prompt,
                    "creative_direction": creative_direction,
                    "layout_notes": layout_notes,
                    "overlay_recommendation": overlay_recommendation,
                    "design_system": design_system,
                    "grid_spec": grid_spec,
                    "text_distribution_rules": text_distribution_rules,
                    "copy_policy": copy_policy,
                    "final_prompt": final_prompt,
                    "final_ranking": final_ranking,
                    "engine_errors": engine_errors,
                })

        except Exception as e:
            print(f"🚨 [ERRO GERAL]: {str(e)}")
            yield _sse({
                "error": f"Erro interno no motor: {str(e)}"
            })

    return StreamingResponse(
        event_generator(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
        },
    )